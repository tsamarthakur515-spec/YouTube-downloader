"""Download API ke liye async client (ek shared session, saaf errors)."""
from __future__ import annotations

import asyncio
import logging

import aiohttp

from config import Settings
from helpers import ApiError, MediaResult, parse_payload

log = logging.getLogger(__name__)


class ApiClient:
    def __init__(self, settings: Settings) -> None:
        self._s = settings
        self._session: aiohttp.ClientSession | None = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=self._s.api_timeout),
                headers={
                    "X-API-Key": self._s.api_key,
                    "Authorization": f"Bearer {self._s.api_key}",
                    "Accept": "application/json",
                    "User-Agent": "yt-downloader-bot/2.0",
                },
            )
        return self._session

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    async def fetch(self, url: str, media_type: str) -> MediaResult:
        """media_type: 'video' ya 'audio'. Fail hone par ApiError raise hota hai."""
        endpoint = f"{self._s.api_url}{self._s.api_endpoint}"
        session = await self._get_session()
        try:
            async with session.get(endpoint, params={"url": url, "type": media_type}) as resp:
                body = await resp.text()
                if resp.status in (401, 403):
                    log.error("API auth fail (%s): API_KEY galat/expired ho sakti hai", resp.status)
                    raise ApiError("API key reject hui. Admin se contact karo.")
                if resp.status == 404:
                    log.error("API 404: %s — API_URL / API_ENDPOINT check karo", endpoint)
                    raise ApiError("API endpoint nahi mila. Admin se contact karo.")
                if resp.status == 429:
                    raise ApiError("Bahut zyada requests. Thodi der baad try karo.")
                try:
                    data = await resp.json(content_type=None)
                except Exception:
                    log.error("API non-JSON (%s): %.300s", resp.status, body)
                    raise ApiError("API ne galat response diya. Baad me try karo.")
                if resp.status != 200:
                    log.warning("API error %s: %.300s", resp.status, body)
                    detail = data.get("error") or data.get("message") if isinstance(data, dict) else None
                    raise ApiError(str(detail)[:300] if detail else f"API error ({resp.status}).")
                return parse_payload(data)
        except asyncio.TimeoutError:
            raise ApiError("API ne time par jawab nahi diya. Dobara try karo.")
        except aiohttp.ClientError as exc:
            log.error("API connection error: %s", exc)
            raise ApiError("API se connect nahi ho paya. Baad me try karo.")
