"""Pure helper logic (koi network / Telegram dependency nahi) — isliye test karna aasan."""
from __future__ import annotations

import re
import secrets
import time
from dataclasses import dataclass
from typing import Any

# watch / shorts / live / embed / youtu.be, www / m / music subdomain
_YOUTUBE_RE = re.compile(
    r"(?:https?://)?(?:(?:www|m|music)\.)?"
    r"(?:youtube\.com/(?:watch\?(?:[^\s&]*&)*v=|shorts/|live/|embed/)|youtu\.be/)"
    r"[\w-]{11}[^\s]*",
    re.IGNORECASE,
)


def extract_youtube_url(text: str) -> str | None:
    """Text me se pehla YouTube link nikaalta hai (scheme na ho to https:// lagata hai)."""
    match = _YOUTUBE_RE.search(text or "")
    if not match:
        return None
    url = match.group(0).rstrip(").,>]")
    if not url.lower().startswith(("http://", "https://")):
        url = "https://" + url
    return url


# ---------------------------------------------------------------- API payload

@dataclass(frozen=True)
class MediaResult:
    url: str
    title: str


class ApiError(Exception):
    """User ko dikhane layak (safe) message ke saath error."""


_URL_KEYS = ("download_url", "downloadUrl", "url", "download", "link", "file")
_TITLE_KEYS = ("title", "name")
_NESTED_KEYS = ("result", "data", "response")


def _pick(d: dict, keys: tuple[str, ...]) -> Any:
    for k in keys:
        v = d.get(k)
        if v:
            return v
    return None


def parse_payload(data: Any) -> MediaResult:
    """Alag-alag API response shapes se download URL + title nikaalta hai."""
    if not isinstance(data, dict):
        raise ApiError("API ka response samajh nahi aaya.")

    if data.get("success") is False or str(data.get("status", "")).lower() in {"error", "failed"}:
        msg = data.get("error") or data.get("message") or "API ne error diya."
        raise ApiError(str(msg)[:300])

    candidates = [data] + [data[k] for k in _NESTED_KEYS if isinstance(data.get(k), dict)]
    title = None
    for c in candidates:
        title = title or _pick(c, _TITLE_KEYS)
        url = _pick(c, _URL_KEYS)
        if isinstance(url, str) and url.startswith(("http://", "https://")):
            return MediaResult(url=url, title=str(title or "YouTube Download"))

    raise ApiError("API response me download link nahi mila.")


# ---------------------------------------------------------------- pending links

class PendingStore:
    """Link ko chhote token ke saath yaad rakhta hai.

    Telegram callback_data 64 bytes tak hi allow karta hai, aur ek chat me
    multiple links aa sakte hain — isliye chat_id ke bajay token use hota hai.
    Purani entries TTL ke baad hat jaati hain, size bounded rehta hai.
    """

    def __init__(self, ttl: int = 3600, max_items: int = 2000) -> None:
        self._ttl = ttl
        self._max = max_items
        self._items: dict[str, tuple[float, str]] = {}

    def _purge(self) -> None:
        now = time.monotonic()
        for k in [k for k, (t, _) in self._items.items() if now - t > self._ttl]:
            del self._items[k]
        while len(self._items) > self._max:
            del self._items[next(iter(self._items))]

    def add(self, url: str) -> str:
        self._purge()
        token = secrets.token_urlsafe(6)
        self._items[token] = (time.monotonic(), url)
        return token

    def get(self, token: str) -> str | None:
        self._purge()
        item = self._items.get(token)
        return item[1] if item else None
