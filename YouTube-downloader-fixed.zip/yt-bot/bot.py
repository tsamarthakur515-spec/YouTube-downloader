"""YouTube Downloader Telegram bot (aiogram 3)."""
from __future__ import annotations

import asyncio
import html
import logging
import os
import re
import tempfile

import aiohttp
from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ChatAction, ParseMode
from aiogram.exceptions import TelegramAPIError
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    CallbackQuery,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)

from api_client import ApiClient
from config import load_settings
from helpers import ApiError, MediaResult, PendingStore, extract_youtube_url

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
)
log = logging.getLogger("bot")

TG_UPLOAD_LIMIT = 50 * 1024 * 1024  # Bot API upload limit
CAPTION_LIMIT = 1024

dp = Dispatcher()
pending = PendingStore()
busy: set[str] = set()  # double-tap se bachne ke liye


def kb(token: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[[
            InlineKeyboardButton(text="🎬 Video", callback_data=f"dl:video:{token}"),
            InlineKeyboardButton(text="🎵 Music", callback_data=f"dl:audio:{token}"),
        ]]
    )


HELP_TEXT = (
    "👋 <b>YouTube Downloader</b>\n\n"
    "🎬 YouTube Video → MP4\n"
    "🎵 YouTube Music → Audio\n\n"
    "Bas YouTube link bhejo."
)


@dp.message(CommandStart())
@dp.message(Command("help"))
async def start(message: Message) -> None:
    await message.answer(HELP_TEXT)


@dp.message(F.text)
async def receive_url(message: Message) -> None:
    url = extract_youtube_url(message.text or "")
    if not url:
        await message.answer(
            "❌ Valid YouTube link bhejo.\n\nExample:\nhttps://youtube.com/watch?v=..."
        )
        return
    token = pending.add(url)
    await message.answer("Link mil gaya ✅\n\nKya download karna hai?", reply_markup=kb(token))


# ------------------------------------------------------------------ sending

def _safe_filename(title: str, ext: str) -> str:
    name = re.sub(r"[^\w\- ]+", "", title, flags=re.UNICODE).strip()[:60] or "download"
    return f"{name}{ext}"


async def _download_to_disk(url: str, dest_dir: str, filename: str) -> str:
    """File download karta hai (size cap ke saath). API key yaha kabhi nahi bheji jaati."""
    path = os.path.join(dest_dir, filename)
    timeout = aiohttp.ClientTimeout(total=600)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.get(url) as resp:
            resp.raise_for_status()
            if (resp.content_length or 0) > TG_UPLOAD_LIMIT:
                raise ValueError("too_large")
            size = 0
            with open(path, "wb") as f:
                async for chunk in resp.content.iter_chunked(256 * 1024):
                    size += len(chunk)
                    if size > TG_UPLOAD_LIMIT:
                        raise ValueError("too_large")
                    f.write(chunk)
    return path


async def _send_media(bot: Bot, chat_id: int, kind: str, media: MediaResult) -> None:
    caption = html.escape(media.title)[:CAPTION_LIMIT]
    icon = "🎬" if kind == "video" else "🎵"
    caption = f"{icon} {caption}"[:CAPTION_LIMIT]
    send = bot.send_video if kind == "video" else bot.send_audio
    field = "video" if kind == "video" else "audio"

    # 1) Telegram ko seedha URL do (fast path)
    try:
        await send(chat_id=chat_id, caption=caption, **{field: media.url})
        return
    except TelegramAPIError as exc:
        log.info("URL se send fail (%s) — upload fallback try kar rahe hain", exc)

    # 2) Khud download karke upload karo
    await bot.send_chat_action(chat_id, ChatAction.UPLOAD_VIDEO if kind == "video" else ChatAction.UPLOAD_VOICE)
    ext = ".mp4" if kind == "video" else ".mp3"
    with tempfile.TemporaryDirectory() as tmp:
        try:
            path = await _download_to_disk(media.url, tmp, _safe_filename(media.title, ext))
        except ValueError:
            # 50MB se badi file — direct link de do
            await bot.send_message(
                chat_id,
                f"⚠️ File 50MB se badi hai, Telegram me nahi bhej sakta.\n\n"
                f'📥 <a href="{html.escape(media.url, quote=True)}">Yaha se download karo</a>',
            )
            return
        await send(chat_id=chat_id, caption=caption, **{field: FSInputFile(path)})


@dp.callback_query(F.data.startswith("dl:"))
async def download_callback(callback: CallbackQuery, bot: Bot, api: ApiClient) -> None:
    if not isinstance(callback.message, Message):
        await callback.answer()
        return

    try:
        _, kind, token = (callback.data or "").split(":", 2)
    except ValueError:
        await callback.answer("Invalid button.", show_alert=True)
        return
    if kind not in {"video", "audio"}:
        await callback.answer("Invalid button.", show_alert=True)
        return

    url = pending.get(token)
    if not url:
        await callback.answer("⌛ Link purana ho gaya. Dobara link bhejo.", show_alert=True)
        return
    if token in busy:
        await callback.answer("Already processing…")
        return

    busy.add(token)
    await callback.answer()
    chat_id = callback.message.chat.id
    status = await callback.message.edit_text("⏳ <b>Processing...</b>\n\nMedia prepare ho raha hai.")
    try:
        media = await api.fetch(url, kind)
        await status.edit_text(f"✅ <b>Ready!</b>\n\n{html.escape(media.title)}\n\n📥 Sending file...")
        await _send_media(bot, chat_id, kind, media)
        await status.delete()
    except ApiError as exc:
        await status.edit_text(f"❌ <b>Download failed</b>\n\n{html.escape(str(exc))}")
    except TelegramAPIError as exc:
        log.exception("Telegram send fail")
        await status.edit_text(
            f"❌ <b>Telegram ne file reject ki</b>\n\n{html.escape(str(exc)[:200])}"
        )
    except Exception:
        log.exception("Unexpected error")
        await status.edit_text("❌ <b>Kuch galat ho gaya.</b>\n\nThodi der baad dobara try karo.")
    finally:
        busy.discard(token)


# --------------------------------------------------------------------- main

async def main() -> None:
    settings = load_settings()
    bot = Bot(settings.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    api = ApiClient(settings)
    dp["api"] = api  # handlers me `api: ApiClient` se milega

    me = await bot.get_me()
    log.info("Bot started: @%s | API: %s%s", me.username, settings.api_url, settings.api_endpoint)
    try:
        await dp.start_polling(bot, allowed_updates=["message", "callback_query"])
    finally:
        await api.close()
        await bot.session.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        pass
