"""Environment se settings load karta hai aur missing values par saaf error deta hai."""
from __future__ import annotations

import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()


def _first_env(*names: str, default: str | None = None) -> str | None:
    """Diye gaye naamo me se pehla non-empty env var return karta hai.

    Purane naam (ARU_*, SHRUTI_*) bhi chalte hain taaki purani .env toote nahi.
    """
    for name in names:
        value = os.getenv(name, "").strip()
        if value:
            return value
    return default


@dataclass(frozen=True)
class Settings:
    bot_token: str
    api_url: str
    api_key: str
    api_endpoint: str
    api_timeout: int


def load_settings() -> Settings:
    bot_token = _first_env("BOT_TOKEN")
    api_key = _first_env("API_KEY", "ARU_API_KEY", "SHRUTI_API_KEY")
    api_url = _first_env(
        "API_URL", "ARU_YT_API", "SHRUTI_API_URL",
        default="https://aruyt.up.railway.app",
    )

    problems: list[str] = []
    if not bot_token:
        problems.append("BOT_TOKEN set nahi hai")
    if not api_key:
        problems.append("API_KEY set nahi hai")
    elif api_key.upper().startswith("YOUR_") or "your_" in api_key.lower():
        problems.append("API_KEY abhi placeholder hai — asli key daalo")
    if problems:
        raise SystemExit(
            "Config error:\n  - " + "\n  - ".join(problems)
            + "\n\n.env.example ko .env me copy karke values bharo."
        )

    endpoint = _first_env("API_ENDPOINT", "ARU_ENDPOINT", default="/download") or "/download"
    if not endpoint.startswith("/"):
        endpoint = "/" + endpoint

    try:
        timeout = int(_first_env("API_TIMEOUT", default="300") or 300)
    except ValueError:
        raise SystemExit("API_TIMEOUT number hona chahiye (seconds)")

    return Settings(
        bot_token=bot_token,  # type: ignore[arg-type]
        api_url=api_url.rstrip("/"),  # type: ignore[union-attr]
        api_key=api_key,  # type: ignore[arg-type]
        api_endpoint=endpoint,
        api_timeout=timeout,
    )
