# YouTube Downloader Bot

Telegram bot: YouTube link bhejo → Video (MP4) ya Music (audio) chuno → file mil jaati hai.

## Setup
```bash
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env        # phir .env me BOT_TOKEN aur API_KEY bharo
python bot.py
```

## Tests
```bash
python tests/test_helpers.py
```

## Files
- `bot.py` – Telegram handlers
- `api_client.py` – download API client
- `helpers.py` – URL parsing, API response parsing, pending-link store
- `config.py` – .env loading + validation
