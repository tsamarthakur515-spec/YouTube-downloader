import sys, unittest, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from helpers import ApiError, PendingStore, extract_youtube_url, parse_payload


class UrlTests(unittest.TestCase):
    def test_valid(self):
        for u in [
            "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            "https://youtu.be/dQw4w9WgXcQ?si=abc",
            "https://youtube.com/shorts/dQw4w9WgXcQ",
            "https://m.youtube.com/watch?v=dQw4w9WgXcQ",
            "https://music.youtube.com/watch?v=dQw4w9WgXcQ&list=RD",
            "https://www.youtube.com/watch?feature=share&v=dQw4w9WgXcQ",
        ]:
            self.assertEqual(extract_youtube_url(u), u, u)

    def test_no_scheme_and_embedded(self):
        self.assertEqual(extract_youtube_url("youtu.be/dQw4w9WgXcQ"), "https://youtu.be/dQw4w9WgXcQ")
        self.assertEqual(
            extract_youtube_url("dekho https://youtu.be/dQw4w9WgXcQ yaar"),
            "https://youtu.be/dQw4w9WgXcQ",
        )

    def test_invalid(self):
        for t in ["hello", "https://example.com/watch?v=dQw4w9WgXcQ", "youtube.com", ""]:
            self.assertIsNone(extract_youtube_url(t), t)


class PayloadTests(unittest.TestCase):
    def test_flat(self):
        r = parse_payload({"download_url": "https://x/y.mp4", "title": "T"})
        self.assertEqual((r.url, r.title), ("https://x/y.mp4", "T"))

    def test_nested(self):
        r = parse_payload({"status": "ok", "result": {"url": "https://x/a.mp3", "title": "A"}})
        self.assertEqual(r.url, "https://x/a.mp3")

    def test_default_title(self):
        self.assertEqual(parse_payload({"url": "https://x"}).title, "YouTube Download")

    def test_errors(self):
        for bad in [[], "x", {}, {"url": "not-a-url"}, {"success": False, "error": "boom"}]:
            with self.assertRaises(ApiError):
                parse_payload(bad)


class StoreTests(unittest.TestCase):
    def test_roundtrip_and_ttl(self):
        s = PendingStore(ttl=0)
        t = s.add("u")
        import time; time.sleep(0.01)
        self.assertIsNone(s.get(t))
        s = PendingStore()
        t = s.add("u")
        self.assertEqual(s.get(t), "u")
        self.assertLessEqual(len(f"dl:video:{t}"), 64)

    def test_bounded(self):
        s = PendingStore(max_items=3)
        for i in range(10):
            s.add(str(i))
        s.add("x")
        self.assertLessEqual(len(s._items), 4)


if __name__ == "__main__":
    unittest.main()
